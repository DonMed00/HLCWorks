<html>
    <body>
        <?php
            $cadena = 'En un lugar de la mancha de cuyo nombre.';
            $cadenaAux = str_replace('lugar','planeta',$cadena);
            echo $cadenaAux;
        ?>
    </body>
</html>