<html>
    <body>
        <?php
            $cadena = 'En un lugar de la mancha de cuyo nombre.';
            $palabra = explode(' ',$cadena);
            echo $palabra[0];
        ?>
    </body>
</html>