<html>
    <body>
        <?php
            $cadena = 'En un lugar de la mancha de cuyo nombre.';
            $cadena2 = 'test';
            echo substr($cadena,0,18),$cadena2,substr($cadena,17,30);
        ?>
    </body>
</html>