<html>
    <body>
        <?php
        $cadena = 'rayy@example.com';
        $word = substr($cadena,-3);
        echo $cadena,'<br>';
        echo $word;
        ?>
    </body>
</html>