<html>
    <body>
        <?php
            $cadena = 'En un  / lugar de  / la mancha de / cuyo nombre.';
            echo str_replace('/ ','',$cadena);
            
        ?>
    </body>
</html>