<html>
    <body>
        <?php
            $cadena = "Uno, dos, tres, cuatro";
            $cadenaArray = explode(', ',$cadena);
            print_r($cadenaArray);
        ?>
    </body>
</html>