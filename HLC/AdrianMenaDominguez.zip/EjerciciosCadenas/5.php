<html>
    <body>
        <div>
            <?php
            $cadena = 'rayy@example.com';
            $tok = strtok($cadena, "@");
            echo $cadena,'<br>';
            echo $tok;
           ?>
        </div>
    </body>
</html>