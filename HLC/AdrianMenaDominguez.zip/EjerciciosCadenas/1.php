<html>
    <body>
        <div>
            <?php
            $cadena = "En un lugar de la mancha de cuyo nombre <br>";
            echo $cadena;
            echo "a) ", strtoupper($cadena);
            echo "b) ", strtolower($cadena);
            echo "c) ", ucfirst($cadena);
            echo "d) ", ucwords($cadena);
            
            ?>
        </div>
    </body>
</html>