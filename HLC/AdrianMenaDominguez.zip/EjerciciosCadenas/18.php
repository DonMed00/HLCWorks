<html>
    <body>
        <?php
            $cadena = 'http://www.example.com/5478631';
            $palabra = explode('/',$cadena);
            echo $palabra[3];
            
        ?>
    </body>
</html>